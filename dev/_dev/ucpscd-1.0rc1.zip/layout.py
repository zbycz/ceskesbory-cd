# -*- coding: utf8 -*-

import wx
import wx.html
import webbrowser


def getTopSizer(self, heading):
    hbox1 = wx.BoxSizer(wx.HORIZONTAL)
    hbox1.Add((20,-1))
    
    # vbox->hbox1->heading
    font = wx.Font(18, wx.DEFAULT, wx.NORMAL, wx.NORMAL, False, 'Verdana')
    heading = wx.StaticText(self, -1, heading)
    heading.SetFont(font)
    hbox1.Add(heading, 1, wx.TOP, 20)
    
    # vbox->hbox1->logo
    gifLogo = wx.Image('logo.gif', wx.BITMAP_TYPE_GIF).ConvertToBitmap()
    logo = wx.StaticBitmap(self, -1, gifLogo, None, (gifLogo.GetWidth(), gifLogo.GetHeight())) #(250, 62)
    hbox1.Add(logo, 0, wx.ALIGN_RIGHT|wx.TOP|wx.RIGHT, 10)
    
    return hbox1;



def CreateFiltrPnl(self, db):
    self.PnlFiltr = wx.Panel(self)
    self.PnlFiltr.Hide()
    
    vbox = wx.BoxSizer(wx.VERTICAL)
    vbox.Add(getTopSizer(self.PnlFiltr, u"Zvolte filtr"), 0, wx.EXPAND)
    vbox.Add((-1,5))

    butt = wx.Button(self.PnlFiltr, -1, u"Zpět na úvod")
    self.Bind(wx.EVT_BUTTON, self.OnSwitchFirst, butt)
    vbox.Add(butt, 0, wx.LEFT, 80)
    vbox.Add((-1,20))
    
    grid1 = wx.GridSizer(cols=2, vgap=5, hgap=5);
    for item in self.form:
        grid1.Add(wx.StaticText(self.PnlFiltr, -1, item[1]), 0, wx.ALIGN_CENTER_VERTICAL|wx.ALIGN_RIGHT)
        
        if item[2] != False:
            tmp = wx.Choice(self.PnlFiltr, -1, choices = db.arr[item[0]])
            tmp.SetSelection(0)
        else:
            tmp = wx.TextCtrl(self.PnlFiltr, -1)
        item.append(tmp)
        grid1.Add(tmp)
    
    vbox.Add(grid1, 0, wx.ALL|wx.CENTER, 20)

    # vbox->button
    butt = wx.Button(self.PnlFiltr, -1, u'Zobrazit výsledky')
    vbox.Add(butt, 0, wx.ALIGN_CENTER)
    self.Bind(wx.EVT_BUTTON, self.OnSwitchVysl, butt)
    
    self.PnlFiltr.SetSizer(vbox)




def CreateHtmlPnl(parent, heading, htmldata, btntxt=False, btnevt=False):
    #vytvoří panel
    Pnl = wx.Panel(parent)
    Pnl.Hide()
    
    #sizer a obrázek
    vbox = wx.BoxSizer(wx.VERTICAL)
    vbox.Add(getTopSizer(Pnl, heading), 0, wx.EXPAND)
    vbox.Add((-1,3))

    #tlačítko
    if btnevt and btnevt:
        butt = wx.Button(Pnl, -1, btntxt)
        parent.Bind(wx.EVT_BUTTON, btnevt, butt)
        vbox.Add(butt, 0, wx.LEFT, 80)
        vbox.Add((-1,5))

    Pnl.html = HtmlWin(Pnl, -1)
    Pnl.html.SetPage(htmldata)

    #ir = Pnl.html.GetInternalRepresentation()
    #ir.SetIndent(0, wx.html.HTML_INDENT_ALL)
    #html.SetSize((ir.GetWidth(), ir.GetHeight()-50))
              
    vbox.Add(Pnl.html, 1, wx.EXPAND)
    Pnl.SetSizer(vbox)
    return Pnl


class HtmlWin(wx.html.HtmlWindow):
    def OnLinkClicked(self, linkinfo):
        href = linkinfo.GetHref()
        if href[:3] == 'id-':
            self.GetParent().GetParent().OnSwitchDetail(int(href[3:]))
        
        else:
            try:
                webbrowser.open(href)
            except:
                wx.MessageBox(u"Adresa: %s" % href, u"Nelze spustit webový prohlížeč", wx.OK | wx.CENTRE | wx.ICON_ERROR)


