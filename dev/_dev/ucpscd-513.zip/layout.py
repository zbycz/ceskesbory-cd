# -*- coding: cp1250 -*-

import wx
import wx.html

def getTopSizer(self, heading):
    hbox1 = wx.BoxSizer(wx.HORIZONTAL)
    hbox1.Add((20,-1))
    
    # vbox->hbox1->heading
    font = wx.Font(18, wx.DEFAULT, wx.NORMAL, wx.NORMAL, False, 'Verdana')
    heading = wx.StaticText(self, -1, heading)
    heading.SetFont(font)
    hbox1.Add(heading, 1, wx.TOP, 20)
    
    # vbox->hbox1->logo
    gifLogo = wx.Image('logo.gif', wx.BITMAP_TYPE_GIF).ConvertToBitmap()
    logo = wx.StaticBitmap(self, -1, gifLogo, None, (gifLogo.GetWidth(), gifLogo.GetHeight())) #(250, 62)
    hbox1.Add(logo, 0, wx.ALIGN_RIGHT|wx.TOP|wx.RIGHT, 10)
    
    return hbox1;





class HtmlWin(wx.html.HtmlWindow):
    def OnLinkClicked(self, linkinfo):
        href = linkinfo.GetHref()
        if href:
            import webbrowser
            webbrowser.open(linkinfo.GetHref(), new=True)






