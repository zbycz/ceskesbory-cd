# -*- coding: utf8 -*-

from sqlite3 import dbapi2 as sqlite
import os.path


arrKraje = {-1: u'- nezáleží -'}
arrDruh = {-1: u'- nezáleží -'}
arrChar = {-1: u'- nezáleží -'}
arrZanr = {-1: u'- nezáleží -'}
arrOrder = [u"- nezáleží -", u"žánru", u"sídla", u"počtu členů", u"druhu souboru", u"roku založení"]



connection = sqlite.connect('ucps.db')
connection.row_factory = sqlite.Row
cursor = connection.cursor()


def close():
    connection.commit()
    cursor.close()


def fillLists():
    cursor.execute("SELECT id,nazev FROM kraje")
    for row in cursor:
        arrKraje[int(row['id'])] = row['nazev']
    
    cursor.execute("SELECT ID,druh FROM druhy")
    for row in cursor:
        arrDruh[int(row['ID'])] = row['druh']
    
    cursor.execute("SELECT ID,charakteristika_kratka FROM dopl_char")
    for row in cursor:
        arrChar[int(row['ID'])] = row[1]
    
    cursor.execute("SELECT ID,zanr FROM zanr")
    for row in cursor:
        arrZanr[int(row['ID'])] = row['zanr']
    
    
    
#cursor.execute('''
#    CREATE INDEX status_CID ON katalog ( status_CID)
#''');
#close()

#cursor.execute("SELECT * FROM SQLITE_MASTER")
# cursor.execute("SELECT status_CID*1 FROM katalog LIMIT 100")
# for r in cursor:
#     print r
#     
# exit()



def getVysledky(userdata):
    
    sql = "SELECT * FROM katalog "
    sql+= "WHERE status_CID*1=88 OR status_CID*1>1 AND status_CID*1 < 11 AND status_CID*1!=4 "
    


    if userdata['nazev']:
        sql += '''
        AND (nazev LIKE '%$chci_hledat%' 
        OR sbm_prijmeni LIKE '%$chci_hledat%' 
        OR sbm1_prijmeni LIKE '%$chci_hledat%' 
        OR sbm2_prijmeni LIKE '%$chci_hledat%' 
        OR sbm3_prijmeni LIKE '%$chci_hledat%' 
        OR sidlo LIKE '%$chci_hledat%' 
        OR sbor_ID LIKE '%$chci_hledat%' 
        OR zrizovatel_nazev LIKE '%$chci_hledat%')
        '''.replace("$chci_hledat", userdata['nazev'].replace("'","''"))
    
    
    
#$sql="SELECT  $hledej_kraj $hledej_druh $hledej_char $hledej_zanr $hledej $orderby";



       
    cursor.execute(); 
    
    data = []
    i = 0
    for row in cursor:
        i+=1
        data.append(getRowHtml(row))
    print i
    return data



def getRowHtml(row):
    if not row["druh_CID"]:
        return u'';
        
    if row["status_CID"]=='88' or row["status_CID"]=='2':
        if row["status_CID"]=='88' or row["status_CID"]=='5':
           txt = u"<br>Podrobné údaje nebyly na přání souboru zveřejněny."
        elif row["status_CID"]=='2':
           txt = u"<br>Sbor neposkytl informace o své činnosti."
        else:
           txt = u""
        
        return u'''
            <p><font color="#666666" size="+1"><u>%s</u></font>
            <table>
            <tr><td><font color="#666666"><b>%s</b> | <b>%s</b> %s</font>
            </table>            
        ''' % (row['nazev'], row['sidlo_obec'], arrDruh[row['druh_CID']], txt)
    
    
    txt = u""
    if row["dopl_char_CID"] in arrChar:
        txt += u" | %s" % arrChar[row["dopl_char_CID"]]
    if row["rok_zal"]:
        txt += u" | založen v roce %s" % row["rok_zal"]
    
    txt += u"<br>umělecký vedoucí: <b>%s</b>" % (row["sbm_jmeno"]+" "+row["sbm_prijmeni"])
    
    if row["status_CID"]==3:
        txt += u"<br><font color='#666'>Zde uvedené informace nebyly sborem autorizovány.</font>"
    
    fotka = u"";
    if os.path.exists("sbory/sbory_%s.jpg" % row["sbor_ID"]):
       fotka += u"<br><font color='#666'>fotografie souboru k dispozici</font>"
    
    return u'''
        <p><a href="id-%s"><font size="+1">%s</font></a>
        <table width="100%%">
        <tr><td><b>%s</b> | <b>%s</b> %s</td>
            <td align="right">%s členů%s</td>
        </tr>
        </table>
    ''' % (row['id'], \
        row["nazev"], \
        row["sidlo_obec"], arrDruh[row["druh_CID"]], txt, row["celkem"], fotka)
   
    




if __name__ == '__main__':
    #cursor.execute("SELECT name FROM SQLITE_MASTER")
    #print cursor.fetchall()
    
    fillLists()
    print getVysledky()
    
    
    #print arrKraje


























