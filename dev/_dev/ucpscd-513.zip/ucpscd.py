# -*- coding: utf8 -*-


# udělat:
#     - arrDruhy apod dát do dvou listů, chytře vybírat
#     - vyzkoušet choice styl: wx.LB_MULTIPLE
#     - udělat html page pro detail



import layout, wx, db



class UcpsSpltr(wx.SplitterWindow):
    PnlActive = False
    PnlFiltr = False
    PnlVysl = False
    PnlDetail = False
    
    def __init__(self, parent):
        wx.SplitterWindow.__init__(self, parent, -1)

        db.fillLists()
        
        self.CreateFiltr()
        self.Initialize(self.PnlFiltr)
        self.PnlActive = self.PnlFiltr
        

    def CreateFiltr(self):
        self.PnlFiltr = wx.Panel(self)
        self.PnlFiltr.Hide()
        
        vbox = wx.BoxSizer(wx.VERTICAL)
        vbox.Add(layout.getTopSizer(self.PnlFiltr, u"Zvolte filtr"), 0, wx.EXPAND)
        vbox.Add((-1,20))
        
        self.form = {}
        self.form['kraj'] = [u'Kraj:', db.arrKraje]
        self.form['nazev'] = [u'Název souboru, sídlo, příjmení sbormistra:', False]
        self.form['druh'] = [u'Druh souboru:', db.arrDruh]
        self.form['char'] = [u'Zvláštní charakteristika:', db.arrChar]
        self.form['zanr'] = [u'Žánrové zaměření:', db.arrZanr]
        #self.form['order'] = [u'Výsledky řadit podle:', db.arrOrder]
        
        grid1 = wx.GridSizer(cols=2, vgap=5, hgap=5);
        for key in self.form:
            grid1.Add(wx.StaticText(self.PnlFiltr, -1, self.form[key][0]), 0, wx.ALIGN_CENTER_VERTICAL|wx.ALIGN_RIGHT)
            
            if self.form[key][1] != False:
                tmp = wx.Choice(self.PnlFiltr, -1, choices = self.form[key][1].values())
                tmp.SetSelection(0)
            else:
                tmp = wx.TextCtrl(self.PnlFiltr, -1)
            self.form[key].append(tmp)
            grid1.Add(tmp)
        
        vbox.Add(grid1, 0, wx.ALL|wx.CENTER, 20)

        # vbox->button
        butt = wx.Button(self.PnlFiltr, -1, u'Zobrazit výsledky')
        vbox.Add(butt, 0, wx.ALIGN_CENTER)
        self.Bind(wx.EVT_BUTTON, self.OnSwitchVysl, butt)
        
        self.PnlFiltr.SetSizer(vbox)


    def CreateVysl(self):
        userdata = {}
        for key in self.form:
            if not self.form[key][1]:
                userdata[key] = self.form[key][2].GetValue()
            else:
                dictkey = -1
                for item in self.form[key][1].iteritems():
                    if item[1] == self.form[key][2].GetStringSelection():
                        dictkey = item[0]
                userdata[key] = dictkey                
        
        print userdata
        exit()
        
        data = db.getVysledky()
        
        #vytvoří panel
        self.PnlVysl = wx.Panel(self)
        self.PnlVysl.Hide()
        
        #sizer a obrázek
        vbox = wx.BoxSizer(wx.VERTICAL)
        vbox.Add(layout.getTopSizer(self.PnlVysl, u"Výsledky vyhledávání"), 0, wx.EXPAND)
        vbox.Add((-1,3))

        #tlačítko 
        butt = wx.Button(self.PnlVysl, -1, u'Změnit filtr')
        self.Bind(wx.EVT_BUTTON, self.OnSwitchFiltr, butt)
        vbox.Add(butt, 0, wx.LEFT, 80)
        vbox.Add((-1,5))

        self.PnlVysl.html = layout.HtmlWin(self.PnlVysl, -1)
        self.PnlVysl.html.SetPage(u''.join(data))

        #ir = html.GetInternalRepresentation()
        #ir.SetIndent(0, wx.html.HTML_INDENT_ALL)
        #html.SetSize((ir.GetWidth(), ir.GetHeight()-50))
                  
        vbox.Add(self.PnlVysl.html, 1, wx.EXPAND)
        self.PnlVysl.SetSizer(vbox)


    def OnSwitchFiltr(self, event):
        self.PnlActive.Hide()
        self.PnlFiltr.Show()
        self.ReplaceWindow(self.PnlActive, self.PnlFiltr)
        self.PnlActive = self.PnlFiltr
        
    
    def OnSwitchVysl(self, event):
        if not self.PnlVysl:
            self.CreateVysl()
        self.PnlActive.Hide()
        self.PnlVysl.Show()
        self.ReplaceWindow(self.PnlActive, self.PnlVysl)
        self.PnlActive = self.PnlVysl



class UcpsFrame(wx.Frame):
    def __init__(self):
        wx.Frame.__init__(self, None, -1, u"České-sbory.cz", (10, 10), (650, 400))
        self.CenterOnScreen()
        self.SetBackgroundColour((255,255,255))
        self.SetIcon(wx.Icon('icon.gif', wx.BITMAP_TYPE_GIF))
        
        
        self.StatusBar = self.CreateStatusBar(1)
        self.StatusBar.SetStatusText(u"Verze: 0.1, databáze: 21.1.2005", 0)
        
        self.Spltr = UcpsSpltr(self)
        self.Refresh()

class UcpsApp(wx.App):
    def OnInit(self):
        self.frame = UcpsFrame()
        self.frame.Show(True)
        self.SetTopWindow(self.frame)
        return True

if __name__ == '__main__':
    app = UcpsApp(False) # False => vypisuj chyby při startu aplikace
    app.MainLoop()
