# -*- coding: utf8 -*-

from sqlite3 import dbapi2 as sqlite
import os.path


arr = {
'kraje': [u'- nezáleží -'],
'krajeId': [-1],
'druh': [u'- nezáleží -'],
'druhId': [-1],
'char': [u'- nezáleží -'],
'charId': [-1],
'zanr': [u'- nezáleží -'],
'zanrId': [-1],
}

arrOrder = [u"- nezáleží -", u"žánru", u"sídla", u"počtu členů", u"druhu souboru", u"roku založení"]



connection = sqlite.connect('ucps.db')
connection.row_factory = sqlite.Row
cursor = connection.cursor()


def close():
    connection.commit()
    cursor.close()



def _fill(name):
    for row in cursor:
        arr[name].append(row[1])
        arr[name+'Id'].append(row[0])
    

def fillLists():
    cursor.execute("SELECT id,nazev FROM kraje")
    _fill('kraje')
    
    cursor.execute("SELECT ID,druh FROM druhy")
    _fill('druh')
    
    cursor.execute("SELECT ID,charakteristika_kratka FROM dopl_char")
    _fill('char')
    
    cursor.execute("SELECT ID,zanr FROM zanr")
    _fill('zanr')
    

def getVysledky(userdata):
    
    sql = "SELECT * FROM katalog "
    sql+= "WHERE (status_CID*1=88 OR status_CID*1>1 AND status_CID*1 < 11 AND status_CID*1!=4) "
    


    if userdata['nazev']:
        sql += '''
        AND (nazev LIKE '%$chci_hledat%' 
        OR sbm_prijmeni LIKE '%$chci_hledat%' 
        OR sbm1_prijmeni LIKE '%$chci_hledat%' 
        OR sbm2_prijmeni LIKE '%$chci_hledat%' 
        OR sbm3_prijmeni LIKE '%$chci_hledat%' 
        OR sidlo LIKE '%$chci_hledat%' 
        OR sbor_ID LIKE '%$chci_hledat%' 
        OR zrizovatel_nazev LIKE '%$chci_hledat%') 
        '''.replace("$chci_hledat", userdata['nazev'].replace("'","''"))
    
    if userdata['kraje'] != -1:
        sql += 'AND kraj_CID="%s" ' % userdata['kraje']
    
    if userdata['druh'] != -1:
        sql += 'AND druh_CID="%s" ' % userdata['druh']
    
    if userdata['char'] != -1:
        sql += 'AND dopl_char_CID="%s" ' % userdata['char']
    
    if userdata['zanr'] != -1:
        sql += 'AND zanr_CID="%s" ' % userdata['zanr']
    
    cursor.execute(sql);     
    data = []
    i = 0
    for row in cursor:
        i+=1
        data.append(getRowHtml(row))
    
    return data



def _select(name, val):
    #for i in arr[name+'Id']:
    #    if arr[name+'Id'][i] == val:
    #        break
    try:
        i = arr[name+'Id'].index(val)
    except ValueError:
        print val;
        print name
        print arr[name]
        exit()
    
    return arr[name][i]
    

def getRowHtml(row):
    if not row["druh_CID"]:
        return u'';
        
    if row["status_CID"] in ('88', '2', '5'):
        if row["status_CID"]=='88' or row["status_CID"]=='5':
           txt = u"<br>Podrobné údaje nebyly na přání souboru zveřejněny."
        elif row["status_CID"]=='2':
           txt = u"<br>Sbor neposkytl informace o své činnosti."
        else:
           txt = u""
        
        return u'''
            <p><font color="#666666" size="+1">%s</font>
            <table>
            <tr><td><font color="#666666"><b>%s</b> | <b>%s</b> %s</font>
            </table>            
        ''' % (row['nazev'], row['sidlo_obec'], _select('druh', row['druh_CID']), txt)
    
    
    txt = u""
    if row["dopl_char_CID"] in arr['char']:
        txt += u" | %s" % _select('char',row["dopl_char_CID"])
    if row["rok_zal"]:
        txt += u" | založen v roce %s" % row["rok_zal"]
    
    txt += u"<br>umělecký vedoucí: <b>%s</b>" % (row["sbm_jmeno"]+" "+row["sbm_prijmeni"])
    
    if row["status_CID"]==3:
        txt += u"<br><font color='#666'>Zde uvedené informace nebyly sborem autorizovány.</font>"
    
    fotka = u"";
    if os.path.exists(os.path.join("images","sbory_%s.jpg" % row["id"])):
       fotka += u"<br><font color='#666'>fotografie souboru k dispozici</font>"
    
    return u'''
        <p><a href="id-%s"><font size="+1">%s</font></a>
        <table width="100%%">
        <tr><td><b>%s</b> | <b>%s</b> %s</td>
            <td align="right">%s členů%s</td>
        </tr>
        </table>
    ''' % (row['id'], \
        row["nazev"], \
        row["sidlo_obec"], _select('druh',row["druh_CID"]), txt, row["celkem"], fotka)
   
    


def getDetail(id):
    cursor.execute("SELECT * FROM katalog WHERE id=? LIMIT 1", (id,)); 
    row = cursor.fetchone()
    
    if row['status_CID'] == 88:
        return u'''
            <h1>%s</h1>
            <h3>%s</h3>
            <p>Pěvecký sbor  si nepřeje zobrazení svých údajů ve veřejném katalogu.
        ''' % (row['nazev'], row['sidlo'])
    
    data = []
    
    data.append(u'<table width="100%">')
    data.append(u'<tr><td><h1>%s <font size="-2">| %s</font></h1>' %  (row['nazev'], row['sidlo_obec']))
    if row['adresa_zverejnit']:
        data.append(u'<br><b>%s, %s, %s %s</b>' %  (row['adresa_osloveni'], row['adresa_ulice'], row['adresa_psc'], row['adresa_obec']))

    # ---------------------------  www a email
    tmp = []
    if row['email']:
        tmp.append(u"<a href='mailto:%s'>%s</a>" % (row['email'],row['email']))
    www = (row['www'], u"")[row['www'] == "http://"]
    if www:
        tmp.append(u"<a href='%s'>%s</a>" % (www,www))
    data.append(u'<br>' + u' ~ '.join(tmp))
    
    # --------------------------- status
    if row['status_CID'] == 3:
        data.append(u"<p><font color='#666'>Zde uvedené informace dosud nebyly sborem autorizovány.</font>")
    
    # --------------------------- logo
    imgpath = os.path.join("images", str(id)+"-logo.jpg")
    if os.path.exists(imgpath):
        data.append(u"<td align=right><img src='%s'>" % imgpath)
    data.append(u'</table>')
    
    
    # -------------------------------- obecné informace
    rok = u"";
    if row['rok_zal'] and row['druh_CID'] > 6:
        rok = u"založené v roce %s" % row['rok_zal'];
    elif row['rok_zal']:
        rok = u"založený v roce %s" % row['rok_zal'];
        
    data.append(u'<table width="100%" cellspacing=0>')
    data.append(u"<tr bgcolor='#eeeeee'><td><b>%s</b> %s" % (_select('druh',row['druh_CID']), rok))
    if row["dopl_char_CID"] in arr['charId']:
        data.append(u"<br><b>%s</b>" % _select('char', row['dopl_char_CID']))
    data.append(u"<br><b>%s</b>" % _select('zanr', row['zanr_CID']))
    
    data.append(u"<p><small>umělecký vedoucí:</small><br> <b>%s</b>" % _sbormistr(row))
    
    # ------------------------------------ sbormistři
    if row['sbm1_prijmeni']:
        data.append(u"<p><small>další sbormistři:</small>")

    for i in range(1,3):
        if row['sbm%s_prijmeni'%i]:
            data.append(u"<br>%s" % _sbormistr(row, "sbm%s"%i))
    
    if row['umpor_prijmeni']:
        data.append(u"<p><small>umělecký poradce:</small><br>%s" % _sbormistr(row, "umpor"))
    
    
    
    # ----------------------------------- členové sboru a INFO
    data.append(u"<p><small>členové sboru:</small><br>")

    cl_m = row['muzi']+row['chlapci']+row['mladici']
    cl_w = row['zeny']+row['divky']+row['slecny']
    if cl_w:
        data.append(u"%s zpěvač%s" % (cl_w, ("ek","ka","ky","ky","ky","ek")[cl_w*(cl_w<=5) + 5*(cl_w>5)] ))
    
    if cl_w and cl_m:
        data.append(u" a ")
        
    if cl_m:
        data.append(u"%s zpěvá%s" % (cl_m, (u"ků","k","ci","ci","ci",u"ků")[cl_m*(cl_m<=5) + 5*(cl_m>5)] ))
    
    
    if row["vek_prumer"]:
        data.append(u"<br>průměrný věk <b>%s let</b>" % row["vek_prumer"]);
    
    if row["frekvence_zkousek"]:
        data.append(u"<br>sbor zkouší <b>%s</b>× týdně" % row["frekvence_zkousek"]);    
    
    if row["soustredeni"]:
        data.append(u"<br>sbor absolvuje <b>%s</b> soustředění ročně" % row["soustredeni"]);    
    
    if row["poznamka_verejna"]:
        data.append(u"<p>Poznámka:<br>%s" % row["poznamka_verejna"]);    
    


    # --------------------------------   obrázky
    data.append(u"<td align=right>")
    for i in (1,2):    
        imgpath = os.path.join("images", "%s-%s.jpg" % (id,i))
        if os.path.exists(imgpath):
            data.append(u"<img src='%s'>" % imgpath)
    
    
    data.append(u"<tr><td> <td> <tr><td colspan=2 bgcolor='#eeeeee'>")
    
    if row['festivaly']:
        data.append(u"<p><b>Účast a ocenění na soutěžích a festivalech</b><br>%s</b>" % \
        row['festivaly'].replace(u"\\\\n",u"</b><br>").replace(u"#", u"</b> » <b>"))
    
    if row['disko']:
        data.append(u"<p><b>Diskografie a rozhlasové nahrávky</b><br>%s" % \
        row['disko'].replace(u"\\\\n",u"<br>"))
    
    if row['kmenovy_repertoar']:
        data.append(u"<p><b>Příklady kmenového repertoáru</b><br>%s" % \
        row['kmenovy_repertoar'].replace(u"\\\\n",u"</b><br>").replace(u"#", u"</b> » <b>"))
    
    if row['premiery']:
        data.append(u"<p><b>Premiéry významných českých děl</b><br>%s" % \
        row['premiery'])
    
    if row['venovane_skladby']:
        data.append(u"<p><b>Skladby věnované sboru</b><br>%s" % \
        row['venovane_skladby'].replace(u"\\\\n",u"<br>"))
    
    if row['zahranicni_projekty']:
        data.append(u"<p><b>Uskutečněné zahraniční projekty</b><br>%s" % \
        row['zahranicni_projekty'].replace(u"\\\\n",u"<br>"))
    
    
    data.append(u"<p align='right'><i><small>Záznam byl založen %s a naposledy aktualizován %s.</small></i>" % (row['zalozeni_profilu'], row['aktualizace']))

    data.append(u"</table>")
    
    
    return u''.join(data)
    
    
    

def _sbormistr(row, sbm="sbm"):
    txt = u'';
    if row[sbm+'_predni_titul']:
        txt += row[sbm+'_predni_titul'] + ' ';
    txt += row[sbm+'_jmeno'] + ' ' + row[sbm+'_prijmeni']
    if row[sbm+'_zadni_titul']:
        txt += ', ' + row[sbm+'_zadni_titul'] 
    return txt


if __name__ == '__main__':
    #cursor.execute("SELECT name FROM SQLITE_MASTER")
    #print cursor.fetchall()
#     cursor.execute("SELECT id,dopl_char_CID FROM katalog")
#     for row in cursor:
#         if row['dopl_char_CID'] != int(row['dopl_char_CID']):
#             print row['id']
#     exit()
    
    
    fillLists()
    data=getDetail(199)
    
    import wx,layout
    app=wx.App()
    frm = wx.Frame(None, -1, u"Test", (10, 10), (650, 400))
    html = layout.HtmlWin(frm, -1)
    html.SetPage(data)
    frm.Show()
    app.MainLoop()



    
#cursor.execute('''
#    CREATE INDEX status_CID ON katalog ( status_CID)
#''');
#close()

#cursor.execute("SELECT * FROM SQLITE_MASTER")
# cursor.execute("SELECT status_CID*1 FROM katalog LIMIT 100")
# for r in cursor:
#     print r
#     
# exit()









