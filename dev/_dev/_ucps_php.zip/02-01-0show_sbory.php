<?php
include "./connect/conn_ucps.php";



#vyb�r� data z tabulky

$hledej_kraj=str_replace("WHERE","AND" ,$chci_kraj);
$hledej_druh=str_replace("WHERE","AND" ,$chci_druh);
$hledej_char=str_replace("WHERE","AND" ,$chci_char);
$hledej_zanr=str_replace("WHERE","AND" ,$chci_zanr);

if ($chci_hledat<>"") {
$hledej="AND (nazev LIKE '%$chci_hledat%' OR sbm_prijmeni LIKE '%$chci_hledat%' OR sbm1_prijmeni LIKE '%$chci_hledat%' OR sbm2_prijmeni LIKE '%$chci_hledat%' OR sbm3_prijmeni LIKE '%$chci_hledat%' OR sidlo LIKE '%$chci_hledat%' OR sbor_ID LIKE '%$chci_hledat%' OR zrizovatel_nazev LIKE '%$chci_hledat%')";
}

$sql="SELECT id, sbor_ID, status_CID, nazev, sidlo_obec, dopl_char_CID, sbm_jmeno, sbm_prijmeni, druh_CID, celkem, zrizovatel_nazev, rok_zal FROM katalog WHERE (((status_CID>1 AND status_CID < 11) AND status_CID<>4) OR status_CID=88) $hledej_kraj $hledej_druh $hledej_char $hledej_zanr $hledej $orderby";



$mysql_result=mysql_query($sql,$connection);
$num_rows=mysql_num_rows($mysql_result);

	if  ( $num_rows == 0 ) {
	?>
	<br><br><br><div style='background-color: #eeeeee; padding: 8px;'>
	<br>
	<p class='vlevo'><b>Nic nebylo nalezeno.</b>
	<p class='vlevomensi'>V 
	<?
	if ($chci_kraj=="") {
	echo "<b>��dn�m kraji </b>"; 
	} else {
	$kraj_CID=substr($chci_kraj,-3,3);
	$kraj=mysql_fetch_array(mysql_query("SELECT nazev FROM kraje WHERE id='$kraj_CID'",$connection));
	echo "kraji <b>".$kraj["nazev"]."</b> ";
	}
	?>
	nen� evidov�n
	<?
	if ($chci_druh=="") {
	echo "<b>��dn� sbor</b>"; 
	} else {
	$druh_CID=substr($chci_druh,-1,1);
	$druh=mysql_fetch_array(mysql_query("SELECT druh FROM druhy WHERE ID='$druh_CID'",$connection));
	echo " ��dn� <b>".$druh["druh"]."</b>";
	}
	?>
	<?
	if ($chci_char=="") {
	} else {
	if (EReg("^WHERE",$chci_char)) {
	$char_CID=substr($chci_char,20);
	} else {
	$char_CID=substr($chci_char,18);
	}
	$char=mysql_fetch_array(mysql_query("SELECT charakteristika FROM dopl_char WHERE ID='$char_CID'",$connection));
	echo " se zvl�tn� charakteristikou <b>".$char["charakteristika"]."</b>";
	}
	?>
	<?
	if ($chci_zanr=="") {
	} else {
	if (EReg("^WHERE",$chci_zanr)) {
	$char_CID=substr($chci_zanr,20);
	} else {
	$char_CID=substr($chci_zanr,18);
	}
	$zanr=mysql_fetch_array(mysql_query("SELECT zanr FROM zanr WHERE id='$zanr_CID'",$connection));
	echo " s ��nrov�m zam��en�m <b>".$zanr[0]."</b>";
	}
	?>
	<?
	if ($chci_hledat<>"") {
	if (EReg("^[[:digit:]]*$",$chci_hledat)) {
	echo " s ��slem <b>$chci_hledat</b>.</P>";
	} else {
	echo " s n�zvem, s�dlem nebo p��jmen�m sbormistra obsahuj�c�m <b>$chci_hledat</b>.</P>";
	}
	} else {
	echo ".";
	}
	?>
	</p><br></div>
	<?
} else {


# hur�, tabulka nejni pr�zdn�!!!
?>
<p id='cervene' class='vlevomensi' style='margin-bottom:0;'><b>V�sledky hled�n�</b></p>
<table align='center' id="sbory_okenko_vysledku"><tr><td>
<br>
<?
while ($row=mysql_fetch_array($mysql_result))
	{
	$status_CID=$row["status_CID"];
	
	
	if ($status_CID==88 OR $status_CID==2) {
	$nazev=$row["nazev"];
	$sidlo_obec=$row["sidlo_obec"];
	$druh_CID=$row["druh_CID"];
	$druh=mysql_fetch_array(mysql_query("SELECT druh FROM druhy WHERE ID='$druh_CID'",$connection));
	$status=mysql_fetch_array(mysql_query("SELECT status FROM katalog_status WHERE id='$status_CID'",$connection));
	?>
	<div id="sbory_abstrakt_sboru">
	<table width=100% cellpadding=0 cellspacing=0><tr><td>
	<p class='sbory_abstrakt_titulek' style='color: #666666'><? echo $nazev ?></a></p>
	<td>
	<tr><td><p class='sbory_abstrakt_mensi' style='color: #666666'><b><? echo $sidlo_obec ?></b> | <b><? echo $druh['druh'] ?></b></p></td>
	<? if ($status_CID==88 OR $status_CID==5) { ?>
	<tr><td><p class='vlevomensi' style='color: 666666'>Podrobn� �daje nebyly na p��n� souboru zve�ejn�ny.</p>
	<? } ?>
	<? if ($status_CID==2) { ?>
	<tr><td><p class='vlevomensi' style='color: 666666'>Sbor neposkytl informace o sv� �innosti.</p>
	<? } ?>
	</table></div>
	<?
	
	} else {
	
	
	$id=$row["id"];
	$sbor_ID=$row["sbor_ID"];
	$nazev=$row["nazev"];
	$sidlo_obec=$row["sidlo_obec"];
	$celkem=$row["celkem"];
	$sbm_jmeno=$row["sbm_jmeno"];
	$sbm_prijmeni=$row["sbm_prijmeni"];
	$druh_CID=$row["druh_CID"];
	$dopl_char_CID=$row["dopl_char_CID"];
	$rok_zal=$row["rok_zal"];
	
	
	$status=mysql_fetch_array(mysql_query("SELECT status FROM katalog_status WHERE id='$status_CID'",$connection));
	$druh=mysql_fetch_array(mysql_query("SELECT druh FROM druhy WHERE ID='$druh_CID'",$connection));
	$char=mysql_fetch_array(mysql_query("SELECT charakteristika FROM dopl_char WHERE ID='$dopl_char_CID'",$connection));
	$sbormistr=$sbm_jmeno." ".$sbm_prijmeni;
	?>
	<div id="sbory_abstrakt_sboru">
	<table width=100% cellpadding=0 cellspacing=0><tr><td>
	<p class='sbory_abstrakt_titulek'>
	<a class='sbory_abstrakt_titulek' href='02-01-detail.php?id=<? echo $id ?>'><? echo $nazev ?></a></p>
	<td>
	<tr><td><p class='sbory_abstrakt_mensi'><b><? echo $sidlo_obec ?></b> | <b><? echo $druh['druh'] ?></b>
	<? if ($char['charakteristika']<>"") { ?>
	<? echo " | ".$char['charakteristika'] ?>
	<? } ?>
	<? if ($rok_zal<>"0") { ?>
	 | zalo�en v roce <? echo $rok_zal ?>
	<? } ?>
	
	</P><td><p class='sbory_abstrakt_mensi_vpravo'><? echo $celkem ?> �len�
	
	<tr><td><p class='sbory_abstrakt_mensi'>um�leck� vedouc�: <b><? echo $sbormistr ?></b></p><td>
	<?
	$obrazek="/DISK2/WWW/ucps.cz/img/sbory/sbory_$sbor_ID.jpg";
	#$obrazek="./img.02/sbory_$sbor_ID.jpg";
	if (File_Exists($obrazek)) { 
	?>
	<p class='sbory_abstrakt_mensi_foto'>fotografie souboru k dispozici
	<? } ?>
	<? if ($status_CID==3) { ?>
	<tr><td><p class='vlevomensi' style='color: 666666'>Zde uveden� informace nebyly sborem autorizov�ny.</p>
	<? } ?>
	
	
	
	<tr><td><p class='sbory_abstrakt_mensi'>
	
	<td></td>
	</table></div>
	
	<?
}
}
}
mysql_close($connection);
?>
</table>
<br>
