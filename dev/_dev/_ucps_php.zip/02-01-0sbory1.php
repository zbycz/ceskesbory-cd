<script type="text/javascript">
function PokrocilyFiltr() {
prepinac_p=document.getElementById('prepinacp').style; 
prepinac_p.display='none';
pf=document.getElementById('pokrocilyfiltr').style; 
pf.display='block';
return false;
}

</script>
<style>
.prepinac_aktivni {
  text-align: right;
  display: block;
  font-size: 8pt;
  color: #990000;
}
.prepinac_neaktivni {
  text-align: right;
  display: none;
  font-size: 8pt;
  color: #990000;
}
.skryj {
  display: none;
}
</style>

<?php
include "./connect/conn_ucps.php";

#vyb�r� data z tabulky
?>
<table cellspacing=0 cellpadding=0 width=100%>
<tr><td><p id='cervene' class='vlevomensi' style='margin-bottom:0;'><b>Nastavte si filtr pro zobrazen� sbor� a ans�mbl�</b></p>
<td>
<p id='prepinacp' class='prepinac_aktivni' style='margin-bottom:0;'><a href='#' onclick='PokrocilyFiltr();'>Pokro�il� filtr =></a></p>
</table>
<table align='center' id="sbory_vyhledavaci_okenko"><tr><td>
<tr><td>
<FORM METHOD=GET ACTION='02-01-index1.php' style='margin-bottom:0; margin-top: 0;'>
<table cellspacing=0><tr><td width=300px><p class='sbory_vyhledavaci_okenko_legenda'>Kraj, v n�m� se m� hledat:</b></p>
<td>
<INPUT TYPE='hidden' NAME='filtr' VALUE='<? echo $filtr ?>'>
<SELECT align='left' NAME='chci_kraj'><OPTION VALUE=''>V�echny kraje
<?
$sql1="SELECT * FROM kraje ORDER by nazev";

$mysql_result=mysql_query($sql1,$connection);
$num_rows=mysql_num_rows($mysql_result);

while ($row=mysql_fetch_array($mysql_result))
{
$kraj=$row["nazev"];
$ID_kraje=$row["id"];
# display results
$ted_kraj="WHERE kraj_CID=$ID_kraje";
if ($chci_kraj==$ted_kraj) {
echo "<OPTION selected VALUE='WHERE kraj_CID=$ID_kraje'>$kraj"; 
} else {
echo "<OPTION VALUE='WHERE kraj_CID=$ID_kraje'>$kraj"; 
}
}
?>
</SELECT>
<tr><td><p class='sbory_vyhledavaci_okenko_legenda'>Slova v n�zvu souboru, s�dle nebo p��jmen� sbormistra</p>
<td>
<INPUT TYPE='TEXT' NAME='chci_hledat' VALUE='<? echo $chci_hledat ?>' size='34'>
<tr><td><p class='sbory_vyhledavaci_okenko_legenda'>Druh souboru, kter� se m� hledat:</b></p>
<td>
<SELECT align='left' class='vlevo' NAME='chci_druh'><OPTION VALUE=''></OPTION>
<?
$sql2="SELECT * FROM druhy";

$mysql_result2=mysql_query($sql2,$connection);
$num_rows=mysql_num_rows($mysql_result2);

while ($row2=mysql_fetch_array($mysql_result2))
{
$druh=$row2["druh"];
$ID_druhu=$row2["ID"];
# display results
$ted_druh="WHERE druh_CID=$ID_druhu";
if ($chci_druh==$ted_druh) {
echo "<OPTION VALUE='WHERE druh_CID=$ID_druhu' SELECTED>$druh"; 
} else {
echo "<OPTION VALUE='WHERE druh_CID=$ID_druhu'>$druh"; 
}
}
?>
</SELECT>
</table>
<div id='pokrocilyfiltr' class='skryj'>
<table cellspacing=0><tr><td>
<tr><td width=300px><p class='sbory_vyhledavaci_okenko_legenda'>Zvl�tn� charakteristika hledan�ch soubor�:</b></p>
<td>
<SELECT align='left' class='vlevomensi' NAME='chci_char'><OPTION VALUE=''></OPTION>
<?
$sql3="SELECT * FROM dopl_char where ID<>99 ORDER by charakteristika ";

$mysql_result3=mysql_query($sql3,$connection);
$num_rows=mysql_num_rows($mysql_result3);

while ($row3=mysql_fetch_array($mysql_result3))
{
$dopl_char=$row3["charakteristika"];
$ID_char=$row3["ID"];
$ted_char="WHERE dopl_char_CID=$ID_char";
if ($chci_char==$ted_char) {
echo "<OPTION VALUE='WHERE dopl_char_CID=$ID_char' SELECTED>$dopl_char"; 
} else {
echo "<OPTION VALUE='WHERE dopl_char_CID=$ID_char'>$dopl_char"; 
}

}
?>
</SELECT>
<tr><td><p class='sbory_vyhledavaci_okenko_legenda'>��nrov� zam��en� hledan�ch soubor�:</p>
<td>
<SELECT align='left' class='vlevomensi' NAME='chci_zanr'><OPTION VALUE=''></OPTION>
<?
$sql3="SELECT * FROM zanr ORDER by zanr";

$mysql_result3=mysql_query($sql3,$connection);
$num_rows=mysql_num_rows($mysql_result3);

while ($row3=mysql_fetch_array($mysql_result3))
{
$zanr=$row3["zanr"];
$ID_zanru=$row3["ID"];
$ted_zanr="WHERE zanr_CID=$ID_zanru";
if ($chci_zanr==$ted_zanr) {
echo "<OPTION VALUE='WHERE zanr_CID=$ID_zanru' SELECTED>$zanr"; 
} else {
echo "<OPTION VALUE='WHERE zanr_CID=$ID_zanru'>$zanr"; 
}

}
?>
</SELECT>
<tr><td><p class='sbory_vyhledavaci_okenko_legenda'>V�sledky se�adit podle</p>
<td><SELECT align='left' class='mensi' NAME='orderby'></p>
<?
if ($orderby=="ORDER BY nazev") {
echo "<OPTION SELECTED VALUE='ORDER BY nazev'>n�zvu";
} else {
echo "<OPTION VALUE='ORDER BY nazev'>n�zvu";
}
if ($orderby=="ORDER BY druh_CID") {
echo "<OPTION SELECTED VALUE='ORDER BY sidlo_obec'>s�dla";
} else {
echo "<OPTION VALUE='ORDER BY sidlo_obec'>s�dla";
}
if ($orderby=="ORDER BY celkem") {
echo "<OPTION SELECTED VALUE='ORDER BY celkem'>po�tu �len�";
} else {
echo "<OPTION VALUE='ORDER BY celkem'>po�tu �len�";
}
if ($orderby=="ORDER BY druh_CID") {
echo "<OPTION SELECTED VALUE='ORDER BY druh_CID'>druhu souboru";
} else {
echo "<OPTION VALUE='ORDER BY druh_CID'>druhu souboru";
}
if ($orderby=="ORDER BY rok_zal") {
echo "<OPTION SELECTED VALUE='ORDER BY rok_zal'>roku zalo�en�";
} else {
echo "<OPTION VALUE='ORDER BY rok_zal'>roku zalo�en�";
}
?>
</SELECT>
</div>

</table>
</table>
<table width=100%><tr><td>
<p class='vlevomensi'>Nejste dosud v katalogu? <a href='predregistrace.php'>Registrujte se!</a></p>
<td>
<p class='vpravo'><INPUT TYPE='SUBMIT' id='sbory_vyhledavaci_tlacitko' VALUE='Hledat'></FORM></P>
</table>
<?
mysql_close($connection);
?>
