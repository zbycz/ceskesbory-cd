<? include "./00-0-prvni-hlavicka.php";
####
$titulek_stranky="Katalog sbor�";
$sekce="02";
$podsekce="";
$nazev_podsekce="";
$ma_byt_prihlasen="Ne";
$pozadovana_uroven_prihlaseni=9;
$jazyk_portalu="Cz";
####
include "./00-0-druha-hlavicka.php" ?>

<h1 class='vpravo'><img src='img.02/ceskesbory.gif' alt='<? echo $titulek_stranky ?>'></h1>

<?
include "./02-01-0sbory1.php";
include "02-01-0show_sbory.php";

?>

<? 
#####
include "./00-0-paticka.php" ?>
