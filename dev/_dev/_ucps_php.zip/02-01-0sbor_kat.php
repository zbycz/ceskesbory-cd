<? 
include "./connect/conn_ucps.php";

if ($zpivame<>"") {
$id=mysql_fetch_array(mysql_query("SELECT sbor_PRF FROM users WHERE login='$zpivame'",$connection));
$id=$id[0];
} 


if ($chci_sbor<>"") {
$sql="SELECT * FROM katalog WHERE sbor_ID='$chci_sbor' AND ((status_CID > 5 AND status_CID < 11) OR status_CID=88 OR status_CID=3 )"; 
} else {
$sql="SELECT * FROM katalog WHERE id='$id' AND ((status_CID > 5 AND status_CID < 11) OR status_CID=88 OR status_CID=3)"; 
}


$mysql_result=mysql_query($sql,$connection);
$num_rows=mysql_num_rows($mysql_result);

if  ( $num_rows == 0 ) {
$nazev_podsekce="";
$titulek_stranky="Neexistuj�c� profil";
$sekce="02";
include "./00-0-druha-hlavicka.php";
echo "<h1>$titulek_stranky </h1><br><br><p>Omlouv�me se, profil sboru nebyl nalezen.";
include "./00-0-paticka.php";
exit;

} else {

# hur�, tabulka nejni pr�zdn�!!!
while ($row=mysql_fetch_array($mysql_result))
{
$status_CID=$row["status_CID"];
if ($status_CID==88) {
$sidlo=$row["sidlo_obec"];
$nazev=$row["nazev"];
$kraj_CID=$row["kraj_CID"];
} else {
$sbor_ID=$row["sbor_ID"];
$id=$row["id"];
$nazev=$row["nazev"];
$kraj_CID=$row["kraj_CID"];
$pripravna_oddeleni=$row["pripravna_oddeleni"];
$sidlo=$row["sidlo_obec"];
$adresa_zverejnit=$row["adresa_zverejnit"];
$adresa_osloveni=$row["adresa_osloveni"];
$adresa_ulice=$row["adresa_ulice"];
$adresa_obec=$row["adresa_obec"];
$adresa_psc=$row["adresa_psc"];
$oblast_CID=$row["oblast_CID"];
$rok_zal=$row["rok_zal"];
$zanr_CID=$row["zanr_CID"];
$disko=$row["disko"];
$festivaly=$row["festivaly"];
$premiery=$row["premiery"];
$venovane_skladby=$row["venovane_skladby"];
$kmenovy_repertoar=$row["kmenovy_repertoar"];
$zahranicni_projekty=$row["zahranicni_projekty"];
$zrizovatel=$row["zrizovatel_nazev"];
$datum_z=$row["zalozeni_profilu"];
$datum0=$row["aktualizace"];
$poznamka_verejna=$row["poznamka_verejna"];
$www=$row["www"];
$email=$row["email"];
$koncerty_cr=$row["koncerty_cr"];
$koncerty_zahr=$row["koncerty_zahr"];
$vystoupeni_cr=$row["vystoupeni_cr"];
$vystoupeni_zahr=$row["vystoupeni_zahr"];
$frekvence_zkousek=$row["frekvence_zkousek"];
$soustredeni=$row["soustredeni"];
$cl_vek_prum=$row["vek_prumer"];
$celkem=$row["celkem"];
$muzi=$row["muzi"];
$chlapci=$row["chlapci"];
$zeny=$row["zeny"];
$divky=$row["divky"];
$mladici=$row["mladici"];
$slecny=$row["slecny"];
$sbor_ID=$row["sbor_ID"];
$sbm_predni_titul=$row["sbm_predni_titul"];
$sbm_jmeno=$row["sbm_jmeno"];
$sbm_prijmeni=$row["sbm_prijmeni"];
$sbm_zadni_titul=$row["sbm_zadni_titul"];
$sbm1_predni_titul=$row["sbm1_predni_titul"];
$sbm1_jmeno=$row["sbm1_jmeno"];
$sbm1_prijmeni=$row["sbm1_prijmeni"];
$sbm1_zadni_titul=$row["sbm1_zadni_titul"];
$sbm2_predni_titul=$row["sbm2_predni_titul"];
$sbm2_jmeno=$row["sbm2_jmeno"];
$sbm2_prijmeni=$row["sbm2_prijmeni"];
$sbm2_zadni_titul=$row["sbm2_zadni_titul"];
$sbm3_predni_titul=$row["sbm3_predni_titul"];
$sbm3_jmeno=$row["sbm3_jmeno"];
$sbm3_prijmeni=$row["sbm3_prijmeni"];
$sbm3_zadni_titul=$row["sbm3_zadni_titul"];
$umpor_predni_titul=$row["umpor_predni_titul"];
$umpor_jmeno=$row["umpor_jmeno"];
$umpor_prijmeni=$row["umpor_prijmeni"];
$umpor_zadni_titul=$row["umpor_zadni_titul"];
$druh_CID=$row["druh_CID"];
$dopl_char_CID=$row["dopl_char_CID"];
}

$www=str_replace("http://","",$www);
$www="http://".$www;

$clanky_ucps=chop($clanky_ucps);
$den_aktualizace=(integer)substr($datum0,8,2);
$mesic_aktualizace=(int)substr($datum0,5,2);
$hodina_aktualizace=(int)substr($datum0,11,2);
$datum_aktualizace=$den_aktualizace.". ".$mesic_aktualizace.". ".substr($datum0,0,4)." v ".$hodina_aktualizace.substr($datum0,13,3);


$den_zalozeni=(integer)substr($datum_z,8,2);
$mesic_zalozeni=(int)substr($datum_z,5,2);
$datum_zalozeni=$den_zalozeni.". ".$mesic_zalozeni.". ".substr($datum_z,0,4);


if  ( $status_CID > 7 ) {


# hur�, tabulka nejni pr�zdn�!!!
$umpor_slovnik_CID=$row["umpor_slovnik_CID"];
$sbm_slovnik_CID=$row["sbm_slovnik_CID"];
$sbm1_slovnik_CID=$row["sbm1_slovnik_CID"];
$sbm2_slovnik_CID=$row["sbm2_slovnik_CID"];
$sbm3_slovnik_CID=$row["sbm3_slovnik_CID"];
$clanky=$row["clanky"];
$oblast_CID=$row["oblast_CID"];

}

$sql0="SELECT sbor_ID FROM sbory100 WHERE sbor_id='$sbor_ID'";

$mysql_result0=mysql_query($sql0,$connection);
$num_rows0=mysql_num_rows($mysql_result0);

if  ($num_rows0==1) {
$praga_cantat="ano";
}
}
}
