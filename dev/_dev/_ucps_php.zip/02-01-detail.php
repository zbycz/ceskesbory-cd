<? include "./00-0-prvni-hlavicka.php";
include "./02-01-0sbor_kat.php";
include "./02-01-0sbor_vzorce.php";
#p�ed�n� prom�nn�ch#
$chci_sbor=$_GET['chci_sbor'];
$chci_kraj=$_GET['chci_kraj'];
$chci_druh=$_GET['chci_druh'];
$chci_char=$_GET['chci_char'];
$chci_hledat=$_GET['chci_hledat'];
$orderby=$_GET['orderby'];
#p�ed�n� prom�nn�ch#

####
$titulek_stranky="$nazev ** $sbor_ID  ";
$sekce="02";
$podsekce="";
$nazev_podsekce="";
$ma_byt_prihlasen="Ne";
$pozadovana_uroven_prihlaseni=0;
$jazyk_portalu="Cz";
####
include "./00-0-druha-hlavicka.php" ?>
<style>@import url('styly/01.css');</style>
<style>@import url('styly/02-katalog.css');</style>



<? if ($status_CID==88) { ?>

<h1 class='jakoH2'><B><? echo $nazev ?></B><br>
<span class='mensi'><b><? echo $sidlo ?></b>
<? if ($kraj_CID<>'1') { ?> 
(<? echo $kraj[0] ?>)
<? } ?>
</span></h1>
<br><br><br>
<br><br><br><div style='background-color: #eeeeee; padding: 8px;'>
<p class='vlevo'><b>�daje o sboru nelze zobrazit</b></p>
<p class='vlevomensi'>P�veck� sbor <b><? echo $nazev ?></b> si nep�eje zobrazen� sv�ch �daj� ve ve�ejn�m katalogu.<br>D�kujeme za pochopen�.</p>
</p><br></div>
<br><br><br><br><br><br><br><br><br>

<?
} else {
?>

<table width=100%><tr><td>
<h1 class='jakoH2'>
<? if ((strlen($nazev))>30) { ?> 
<span class=trochumensi>
<? } ?>
<B><? echo $nazev ?></B></span>
<? if ((strlen($nazev)+strlen($sidlo)+strlen($kraj[0]))>50) { ?>
<span class='mensi'><br>
<? } else { ?>
<span class='mensi'> | 
<? } ?>
<b><? echo $sidlo ?></b>
<? if ($kraj_CID<>'1') { ?> 
(<? echo $kraj[0] ?>)
<? } ?>
</span></h1>
<p class='profil_adresa_sboru'><b>
<? if ($adresa_zverejnit==1) { ?>
 <br><? echo "$adresa_osloveni, $adresa_ulice, $adresa_psc $adresa_obec" ?></b>
<? } ?>
<? if ($email<>"" OR ($www<>"" AND $www<>"http://")) {
  echo "<br>";
  if ($email<>"" ){
  echo "<a href='mailto:$email'>$email</a>";
 }
 if ($email<>"" AND ($www<>"" AND $www<>"http://")) {
  echo " ~ ";
 }
 if ($www<>"" AND $www<>"http://") {
  echo "<a href='$www' target='_blank' title='$www'>$www_kratky</a></p>";
 }
} ?>
</p>
<? if ($status_CID==3) { ?>
<br><p class='profil_adresa_sboru' style='color: 666666'>Zde uveden� informace dosud nebyly sborem autorizov�ny.</p>
<? } ?>
<td width=80px>
<?
$logo_jpg="../../../img/sbor/$id-logo.jpg";
if (File_Exists($logo_jpg)) { ?>
<center><img src='http://img.ucps.cz/sbor/<? echo $id ?>-logo.jpg' alt="<? echo $nazev ?>"></center>
<? } ?>
</table>
<div id=sedaplocha>
<div id='profil_levy_sloupec0'>
<div id='profil_levy_sloupec'>


 <p class='sbory_detail_vlevo'><b> <span class=cervene><? echo $druh["druh"] ?></span></b> 
<? if ($rok_zal<>"NULL" && $rok_zal <>"0") { 
if ($druh_CID>"6") { 
echo "zalo�en� v roce $rok_zal"; 
} else {
echo "zalo�en� v roce $rok_zal"; 
}
} ?>
</p>
 <?
 if ($char["charakteristika"]<>"") {
 ?>
 <p class='sbory_detail_vlevo'><b><? echo $char["charakteristika"] ?></b></P>
 <?
 }
 ?>
 <p class='sbory_detail_vlevo'><b><? echo $zanr["zanr"] ?></b></P>
 <br>
<? 
if ($pripravna_oddeleni<>"NULL" && $pripravna_oddeleni<>"") { 
echo "<p class='sbory_detail_popis_udaje'>p��pravn� odd�len�:</p>";
echo "<p class='sbory_detail_vlevo'><b>$pripravna_oddeleni</b></p><br>";
}
?>
 

  <?
  if ($sbm_slovnik_CID<>"" AND $sbm_slovnik_CID<>"0") {
  ?>
  <p class='sbory_detail_popis_udaje'>um�leck� vedouc�:<p class='sbory_detail_vlevo'><b><a href='03-01-heslo.php?chci_heslo=<?echo $sbm_slovnik_CID ?>'><? echo $sbormistr ?></a></b>
  <? } else { ?>
  <p class='sbory_detail_popis_udaje'>um�leck� vedouc�<p class='sbory_detail_vlevo'><b><? echo $sbormistr ?></b>
  <?
  }
  $jmeno_pro_ceny=$sbm_jmeno." ".$sbm_prijmeni;

  $sql="SELECT * FROM ceny_udelene WHERE sbm_jmeno='$jmeno_pro_ceny' ORDER BY cena_CID";
  $mysql_result=mysql_query($sql,$connection);
  $num_rows=mysql_num_rows($mysql_result);
  if  ( $num_rows!=0 ) {
  echo "<span class='udelenacena'>";
  # hur�, tabulka nejni pr�zdn�!!!
  while ($row=mysql_fetch_array($mysql_result))
  {
  $cena_CID=$row['cena_CID'];
  $rok=$row['rok'];
  $zkratka=mysql_fetch_array(mysql_query("SELECT zkratka FROM ceny_ciselnik WHERE id_ceny='$cena_CID'",$connection));
  $cena=mysql_fetch_array(mysql_query("SELECT nazev FROM ceny_ciselnik WHERE id_ceny='$cena_CID'",$connection));
  ?>
  <a class='nepodtrzeny' href='03-02-prehled.php' title='<?echo "$cena[0] ($rok)"; ?>'>[�]</a>
  <?
  }
  }
  ?> </span></P>
 <?
 if ($sbm1_prijmeni<>"") {
 ?>
 <? if ($sbm1_slovnik_CID<>"0" AND $sbm1_slovnik_CID<>"") { ?>
 <p class='sbory_detail_popis_udaje'>dal�� sbormist�i</p><p class='sbory_detail_vlevo'><a href='03-01-heslo.php?chci_heslo=<?echo $sbm1_slovnik_CID ?>'><? echo $sbormistr1 ?></a></b>
 <? } else { ?>
 <p class='sbory_detail_popis_udaje'>dal�� sbormist�i</P> <p class='sbory_detail_vlevo'><? echo $sbormistr1 ?></b>
 <? }
  $jmeno_pro_ceny=$sbm1_jmeno." ".$sbm1_prijmeni;
  $sql="SELECT * FROM ceny_udelene WHERE sbm_jmeno='$jmeno_pro_ceny' ORDER BY cena_CID";
  $mysql_result=mysql_query($sql,$connection);
  $num_rows=mysql_num_rows($mysql_result);
  if  ( $num_rows!= 0 ) {
   echo "<span class='udelenacena'>";
   # hur�, tabulka nejni pr�zdn�!!!
   while ($row=mysql_fetch_array($mysql_result))
   {
   $cena_CID=$row['cena_CID'];
   $rok=$row['rok'];
   $zkratka=mysql_fetch_array(mysql_query("SELECT zkratka FROM ceny_ciselnik WHERE id_ceny='$cena_CID'",$connection));
   $cena=mysql_fetch_array(mysql_query("SELECT nazev FROM ceny_ciselnik WHERE id_ceny='$cena_CID'",$connection));
   ?>
  <a class='nepodtrzeny' href='03-02-prehled.php' title='<?echo "$cena[0] ($rok)"; ?>'>[�]</a>
  <?
  }
  }
  ?> </span></p> <?
   }

 if ($sbm2_prijmeni<>"") {
 if ($sbm2_slovnik_CID<>"0" AND $sbm2_slovnik_CID<>"") { ?>
 <p class='sbory_detail_vlevo'><a href='03-01-heslo.php?chci_heslo=<?echo $sbm2_slovnik_CID ?>'><? echo $sbormistr2 ?></a></b>
 <? } else { ?>
 <p class='sbory_detail_vlevo'><? echo $sbormistr2 ?></b>
 <? }
  $jmeno_pro_ceny=$sbm2_jmeno." ".$sbm2_prijmeni;
  $sql="SELECT * FROM ceny_udelene WHERE sbm_jmeno='$jmeno_pro_ceny' ORDER BY cena_CID";
  $mysql_result=mysql_query($sql,$connection);
  $num_rows=mysql_num_rows($mysql_result);
  if  ( $num_rows != 0 ) {
  echo "<span class='udelenacena'>";
  # hur�, tabulka nejni pr�zdn�!!!
  while ($row=mysql_fetch_array($mysql_result))
  {
  $cena_CID=$row['cena_CID'];
  $rok=$row['rok'];
  $zkratka=mysql_fetch_array(mysql_query("SELECT zkratka FROM ceny_ciselnik WHERE id_ceny='$cena_CID'",$connection));
  $cena=mysql_fetch_array(mysql_query("SELECT nazev FROM ceny_ciselnik WHERE id_ceny='$cena_CID'",$connection));
  ?>
  <a class='nepodtrzeny' href='03-02-prehled.php' title='<?echo "$cena[0] ($rok)"; ?>'>[�]</a>
  <?
  }
  }
  ?> </span></p> <?
 }
 if ($sbm3_prijmeni<>"") {
 if ($sbm3_slovnik_CID<>"0" AND $sbm3_slovnik_CID<>"") { ?>
 <p class='sbory_detail_vlevo'><a href='03-01-heslo.php?chci_heslo=<?echo $sbm3_slovnik_CID ?>'><? echo $sbormistr3 ?></a></b>
 <? } else { ?>
 <p class='sbory_detail_vlevo'><? echo $sbormistr3 ?></b>
 <? }
  $jmeno_pro_ceny=$sbm3_jmeno." ".$sbm3_prijmeni;
  $sql="SELECT * FROM ceny_udelene WHERE sbm_jmeno='$jmeno_pro_ceny' ORDER BY cena_CID";
  $mysql_result=mysql_query($sql,$connection);
  $num_rows=mysql_num_rows($mysql_result);
  if  ( $num_rows != 0 ) {
  echo "<span class='udelenacena'>";
  while ($row=mysql_fetch_array($mysql_result))
  {
  $cena_CID=$row['cena_CID'];
  $rok=$row['rok'];
  $zkratka=mysql_fetch_array(mysql_query("SELECT zkratka FROM ceny_ciselnik WHERE id_ceny='$cena_CID'",$connection));
  $cena=mysql_fetch_array(mysql_query("SELECT nazev FROM ceny_ciselnik WHERE id_ceny='$cena_CID'",$connection));
  ?>
  <a class='nepodtrzeny' href='03-02-prehled.php' title='<?echo "$cena[0] ($rok)"; ?>'>[�]</a>
  <?
  }
  }
  ?> </span></p> <?
  }
  ?>
 <?
 if ($umpor_prijmeni<>"") {
 if ($umpor_slovnik_CID<>"0") {
 ?>
 <p class='sbory_detail_popis_udaje'>um�leck� poradce<p class='sbory_detail_vlevo'><a href='03-01-heslo.php?chci_heslo=<?echo $umpor_slovnik_CID ?>'><? echo $umpor ?></a></b> 
 <?
 } else {
 ?>
 <p class='sbory_detail_popis_udaje'>um�leck� poradce<p class='sbory_detail_vlevo'><? echo $umpor ?></b>
 <?
 }
  $jmeno_pro_ceny=$umpor_jmeno." ".$umpor_prijmeni;
  $sql="SELECT * FROM ceny_udelene WHERE sbm_jmeno='$jmeno_pro_ceny' ORDER BY cena_CID";
  $mysql_result=mysql_query($sql,$connection);
  $num_rows=mysql_num_rows($mysql_result);
  if  ( $num_rows != 0 ) {
  echo "<span class='udelenacena'>";
  while ($row=mysql_fetch_array($mysql_result))
  {
  $cena_CID=$row['cena_CID'];
  $rok=$row['rok'];
  $zkratka=mysql_fetch_array(mysql_query("SELECT zkratka FROM ceny_ciselnik WHERE id_ceny='$cena_CID'",$connection));
  $cena=mysql_fetch_array(mysql_query("SELECT nazev FROM ceny_ciselnik WHERE id_ceny='$cena_CID'",$connection));
  ?>
  <a class='nepodtrzeny' href='03-02-prehled.php' title='<?echo "$cena[0] ($rok)"; ?>'>[�]</a>
  <?
  }
  }
  ?> </span></p> 
<?  }  ?>

 <p class='sbory_detail_popis_udaje'>�lenov� sboru
 <p class='sbory_detail_vlevo'>
 <?
 if ($cl_zpevacky<>"") {
 ?>
  <? echo $cl_zpevacky ?></b> 
  <?
  switch ($cl_zpevacky) {
  case 1:
  echo "zp�va�ka";
  break;
  case 2:
  echo "zp�va�ky";
  break;
  case 3:
  echo "zp�va�ky";
  break;
  case 4:
  echo "zp�va�ky";
  break;
  default:
  echo "zp�va�ek";
  break;
  }
  ?>
 <?
 }
 if ($cl_zpevacky<>"" AND $cl_zpevaci<>"") {
 ?>
 a 
 <?
 }
 if ($cl_zpevaci<>"") {
 ?>
  <? echo $cl_zpevaci ?></b> 
  <?
  switch ($cl_zpevaci) {
  case 1:
  echo "zp�v�k";
  break;
  case 2:
  echo "zp�v�ci";
  break;
  case 3:
  echo "zp�v�ci";
  break;
  case 4:
  echo "zp�v�ci";
  break;
  default:
  echo "zp�v�k�";
  break;
  }
  ?>
 <?
 }
 ?>
 </p>
  <?
 if ($cl_vek_prum<>"" AND $cl_vek_prum<>"0") {
 ?>
  <p class='sbory_detail_vlevomensi'>pr�m�rn� v�k<b> <? echo $cl_vek_prum ?> let</b></p>
 <?
 }
 ?>
<?  if ($frekvence_zkousek<>"") { ?>
<p class='sbory_detail_popis_udaje'>sbor zkou�� <b><? echo $frekvence_zkousek ?></b>� t�dn�</p>
<? } ?>


<?  if ($soustredeni<>"") { ?>
<p class='sbory_detail_popis_udaje'>sbor absolvuje <b><? echo $soustredeni ?></b> soust�ed�n� ro�n�</p> 
 <? } ?>

<?  if ($poznamka_verejna<>"") { ?>
<p class='sbory_detail_popis_udaje'>Pozn�mka:</p>
<p class='sbory_detail_vlevomensi'><? echo $poznamka_verejna ?></p> 
 <? } ?>


</div>
</div>

<? #################################### ?>
<div id='profil_pravy_sloupec0'>
<div id='profil_pravy_sloupec'>

<? 
$obrazek="../../../img/sbor/$id-1.jpg";
$obrazek1="../../../img/sbor/$id-2.jpg";
?>
<? if (File_Exists($obrazek) OR File_Exists($obrazek1) ) { ?>
<? } ?>
<? if (File_Exists($obrazek)) { ?>
<img src='http://img.ucps.cz/sbor/<? echo $id ?>-1.jpg' alt="<? echo $nazev ?>" style='float=right; margin-bottom: 6px; border: solid 1px #999999'>
<? } ?>
<? if (File_Exists($obrazek1)) { ?>
<img src='http://img.ucps.cz/sbor/<? echo $id ?>-2.jpg' alt="<? echo $nazev ?>" style='float=right; margin-bottom: 6px; border: solid 1px #999999'>
<? } ?>



</div>
</div>
<hr class="profil_cleaner" />
</div>

<? #################################### ?>




<div id=sedaplocha>

<? if ($festivaly<>"" AND $festivaly<>" ") { ?>
<div id='sbory_detail_uspechy_nadpis'>
<p class='sbory_detail_uspechy_nadpis'><b>��ast a ocen�n� na sout��ch a festivalech</b></p>
</div><div id='sbory_detail_uspechy_text'>
<p class='soutez'><b><? echo $festivaly ?></b></p>
</div>
<? } ?>

<? if ($disko<>"" AND $disko<>" ") { ?>
<div id='sbory_detail_uspechy_nadpis'>
<p class='sbory_detail_uspechy_nadpis'><b>Diskografie a rozhlasov� nahr�vky</b></p>
</div><div id='sbory_detail_uspechy_text'>
<p class='sbory_detail_uspechy'><b><? echo $disko ?></b></p>
</div>
<? } ?>

<? if ($kmenovy_repertoar<>"") { ?>
<div id='sbory_detail_uspechy_nadpis'>
<p class='sbory_detail_uspechy_nadpis'><b>P��klady kmenov�ho reperto�ru</b></p>
</div><div id='sbory_detail_uspechy_text'>
<p class='sbory_detail_uspechy'><? echo $kmenovy_repertoar ?></b></p>
</div>
<? } ?>

<? if ($premiery<>"" AND $premiery<>" ") { ?>
<div id='sbory_detail_uspechy_nadpis'>
<p class='sbory_detail_uspechy_nadpis'><b>Premi�ry v�znamn�ch �esk�ch d�l</b></p>
</div><div id='sbory_detail_uspechy_text'>
<p class='sbory_detail_uspechy'><? echo $premiery ?></p>
</div>
<? } ?>

<? if ($venovane_skladby<>"" AND $venovane_skladby<>" ") { ?>
<div id='sbory_detail_uspechy_nadpis'>
<p class='sbory_detail_uspechy_nadpis'><b>Skladby v�novan� sboru</b></p>
</div><div id='sbory_detail_uspechy_text'>
<p class='sbory_detail_uspechy'><? echo $venovane_skladby ?></p>
</div>
<? } ?>

<? if ($zahranicni_projekty<>"") { ?>
<div id='sbory_detail_uspechy_nadpis'>
<p class='sbory_detail_uspechy_nadpis'><b>Uskute�n�n� zahrani�n� projekty</b></p>
</div><div id='sbory_detail_uspechy_text'>
<p class='sbory_detail_uspechy'><? echo $zahranicni_projekty ?></p>
</div>
<? } ?>

<br>

</div>
</div>

<? if ($status_CID>6 AND $status_CID<10) { ?>
<div id='sbory_rozsireny_pravy_sloupec'>
<? include "./02-01-0akce_sboru08.php"; ?>
<?
$sql_file="SELECT * FROM sbory_download WHERE sbor_CID='$sbor_ID' ORDER by date DESC";
$mysql_result_file=mysql_query($sql_file,$connection);
$num_rows_file=mysql_num_rows($mysql_result_file);
if ($num_rows_file>'0') {
include "./02-01-0soubory08.php"; 
}
?>
</div>
<? } ?>


<?
$sql="SELECT nadpis, text, datetime FROM blog WHERE sbor_PRF=$id ORDER BY datetime DESC LIMIT 3";

$mysql_result=mysql_query($sql,$connection);
$num_rows=mysql_num_rows($mysql_result);

if  ( $num_rows <> 0 ) {
?>
<div id='sbory_detail_clanky'>
 <p class='sbory_detail_clanky'>Nejnov�j�� z�pisky v blogu | <a href='02-01-blog.php?id=<? echo $id ?>'>p�ej�t na blog sboru</a></p>
 </div>
 <?
while ($row=mysql_fetch_array($mysql_result))
  {
  $nadpis_blog=$row['nadpis'];
  $datum0=$row['datetime'];
  $text_blog=substr($row['text'],0,200)."...";
  $den_aktualizace=(integer)substr($datum0,8,2);
$mesic_aktualizace=(int)substr($datum0,5,2);
$hodina_aktualizace=(int)substr($datum0,11,2);
$datetime=$den_aktualizace.". ".$mesic_aktualizace.". ".substr($datum0,0,4)." v ".$hodina_aktualizace.substr($datum0,13,3);


?>

<a href='02-01-blog.php?id=<? echo $id ?>'>
 <div style='margin-left: 10px; cursor:hand'>
<div id=abstrakt_clanku>
 <p class='vlevomensi' style='text-decoration: none ! important'><b><? echo $nadpis_blog ?></b><br>publikov�no <? echo $datetime ?></p>
 <p class='vlevomensi' style='text-decoration: none ! important'><? echo $text_blog ?></p>
</div>
</div>
</a>
<?
} 
} 
?>
<?
if ($clanky<>"") {
?>
<div id='sbory_detail_clanky'>
 <p class='sbory_detail_clanky'>Souvisej�c� �l�nky</p>
 </div>
<?
$today1 = getdate(); 
$mesic_dnes = $today1['mon']; 
$den_dnes = $today1['mday']; 
$rok_dnes = $today1['year']; 

#dvojm�stnost ��sel dne a m�s�ce
if ($mesic_dnes < 10 && $mesic_dnes <> "") {
$mesic_dnes = "0".$mesic_dnes;
}

if ($den_dnes < 10) {
$den_dnes = "0".$den_dnes;
}

$datum_dnes=$rok_dnes.$mesic_dnes.$den_dnes;

$token= StrTok ($clanky, "\n");
while ($token):
$sql_clanky="SELECT nazev, podtitul, text, shrnuti, kategorie_CID, id, datum, pasovka, autor, ztisku_zdroj, ztisku_server, ztisku_adresa FROM clanky WHERE datum <= $datum_dnes AND id=$token";

$mysql_result0=mysql_query($sql_clanky,$connection);
$num_rows0=mysql_num_rows($mysql_result0);

if ($num_rows0==0) {
} else {
include "./02-01-0abstrakty_clanku2.php";
}
  $token = StrTok ("\n");
endwhile;
}


?>
</div>
<hr class='sbory_detail_hr'>
</b><p class='sbory_aktualizace'>Z�znam byl zalo�en <? echo $datum_zalozeni ?> a naposledy aktualizov�n <? echo $datum_aktualizace ?>.</b></P>
<?
}

mysql_close($connection);
?>

<? 
#####
include "./00-0-paticka.php" ?>
