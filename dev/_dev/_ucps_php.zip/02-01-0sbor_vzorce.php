<?
if (StrLen($www)>30) {
$www_kratky=SubStr($www,0,27)."...";
} else {
$www_kratky=$www;
}

$cl_zpevaci=$muzi+$chlapci+$mladici;
$cl_zpevacky=$zeny+$divky+$slecny;

$vystoupeni_u_nas=$koncerty_cr+$vystoupeni_cr;
$vystoupeni_v_zahr=$koncerty_zahr+$vystoupeni_zahr;

$kmenovy_repertoar=NL2BR($kmenovy_repertoar);
$zahranicni_projekty=NL2BR($zahranicni_projekty);
$disko=NL2BR($disko);
$premiery=NL2BR($premiery);
$souteze_u_nas=NL2BR($souteze_u_nas);
$souteze_zahr=NL2BR($souteze_zahr);
$disko=StripSlashes($disko);
$premiery=StripSlashes($premiery);
$venovane_skladby=StripSlashes($venovane_skladby);
$festivaly=StripSlashes($festivaly);
$souteze_zahr=StripSlashes($souteze_zahr);
$disko=ERegI_replace("(\n)", "</p><p class='sbory_detail_uspechy'><b>" ,$disko);
$disko=ERegI_replace("(,)", "</b>," ,$disko);

$kmenovy_repertoar=ERegI_replace("(\n)", "</b>" ,$kmenovy_repertoar);
$kmenovy_repertoar=ERegI_replace("#", "</b>�� <b>" ,$kmenovy_repertoar);

$venovane_skladby=NL2BR($venovane_skladby);

$festivaly=NL2BR($festivaly);
$festivaly=StripSlashes($festivaly);
$festivaly=ERegI_replace("<br />", "</font></b></p><p class='soutez'><b>" ,$festivaly);
$festivaly=ERegI_replace("\(", "</b> (" ,$festivaly);
$festivaly=ERegI_replace("#", "<br>� " ,$festivaly);

$status=mysql_fetch_array(mysql_query("SELECT status FROM katalog_status WHERE id='$status_CID'",$connection));
$oblast=mysql_fetch_array(mysql_query("SELECT oblast FROM oblasti WHERE ID_oblasti='$oblast_CID'",$connection));
$zanr=mysql_fetch_array(mysql_query("SELECT zanr FROM zanr WHERE ID='$zanr_CID'",$connection));
if ($zanr['zanr']=="bez omezen�") {
$zanr['zanr']="bez ��nrov�ho omezen�";
}
$druh=mysql_fetch_array(mysql_query("SELECT druh FROM druhy WHERE ID='$druh_CID'",$connection));
$char=mysql_fetch_array(mysql_query("SELECT charakteristika FROM dopl_char WHERE ID='$dopl_char_CID'",$connection));
$kraj=mysql_fetch_array(mysql_query("SELECT nazev FROM kraje WHERE id='$kraj_CID'",$connection));
$kraj[0]=ERegI_replace(" ", "�" ,$kraj[0]);

if ($sbm_zadni_titul<>"") {
$sbormistr=$sbm_predni_titul." ".$sbm_jmeno." ".$sbm_prijmeni.", ".$sbm_zadni_titul;
} else {
$sbormistr=$sbm_predni_titul." ".$sbm_jmeno." ".$sbm_prijmeni;
}
if ($sbm1_zadni_titul<>"") {
$sbormistr1=$sbm1_predni_titul." ".$sbm1_jmeno." ".$sbm1_prijmeni.", ".$sbm1_zadni_titul;
} else {
$sbormistr1=$sbm1_predni_titul." ".$sbm1_jmeno." ".$sbm1_prijmeni;
}
if ($sbm2_zadni_titul<>"") {
$sbormistr2=$sbm2_predni_titul." ".$sbm2_jmeno." ".$sbm2_prijmeni.", ".$sbm2_zadni_titul;
} else {
$sbormistr2=$sbm2_predni_titul." ".$sbm2_jmeno." ".$sbm2_prijmeni;
}
if ($sbm3_zadni_titul<>"") {
$sbormistr3=$sbm3_predni_titul." ".$sbm3_jmeno." ".$sbm3_prijmeni.", ".$sbm3_zadni_titul;
} else {
$sbormistr3=$sbm3_predni_titul." ".$sbm3_jmeno." ".$sbm3_prijmeni;
}
if ($umpor_zadni_titul<>"") {
$umpor=$umpor_predni_titul." ".$umpor_jmeno." ".$umpor_prijmeni.", ".$umpor_zadni_titul;
} else {
$umpor=$umpor_predni_titul." ".$umpor_jmeno." ".$umpor_prijmeni;
}
?>



